import pandas as pd


# Read in data
data = pd.read_csv("design_style_grid.csv", index_col="style")
styles = data.index.tolist()
all_spectrums = [
    "Industrial--Rustic",
    "Formal--Informal",
    "Traditional--Modern",
    "Maximalist--Minimalist",
]

# Convert style-spectrum data to list of lists
X = data.to_numpy().tolist()  # list of lists, 33 by 4


def get_styles(X: list[list[int]], usr_pnt: list[int], styles: list[str]):
    """Get Top 3 Styles Given Slider Positions

    Given the matrix X, which is how each style scores on each spectrum, and the current
    positions of the sliders, return the styles that are the closest to the current
    slider positions. This is currently done by the lowest sum of absolute errors.

    We also don't include any styles with a difference of greater than 25 on the
    traditional-modern spectrum.

    Parameters
    ----------
    X : list[list[int]]
        styles by spectrums. list of 33 lists of 4 with how each style scores on each
        spectrum.
    usr_pnt : list[int]
        List of 4, the current slider positions.
    styles : list[str]
        List of available styles, length 33

    Returns
    -------
    list[str]
        List of 3 chosen styles
    """

    errors = []

    # Iterate through matrix, getting sum of absolute differences for each styl
    for i in range(len(X)):
        err = 0
        for j in range(len(all_spectrums)):
            # Difference between sliders and styles for style i and spectrum j
            curr_err = abs(X[i][j] - usr_pnt[j])

            # If error on traditional-modern spectrum > 25, remove from consideration
            if (all_spectrums[j] == "Traditional--Modern") & (curr_err > 25):
                curr_err += 1000

            err += curr_err
        errors.append(err)

    # Find the lowest 3 error values
    curr_styles = []
    for _ in range(3):
        # Location of minimum value
        idx = errors.index(min(errors))

        # Add style
        curr_styles.append(styles[idx])

        # Replace chosen style with high error value
        errors[idx] += 1000

    return curr_styles


def get_desc(slider_pos):
    desc = ""
    for s, spec in zip(slider_pos, all_spectrums):
        p = s / 100
        s1, s2 = spec.split("--")
        if p > 0.5:
            desc += f"{p:.0%} {s1}"
        elif p < 0.5:
            desc += f"{1 - p:.0%} {s2}"
        else:
            desc += f"50% {s1}/{s2}"
        desc += "; "

    return desc


# Show a couple examples
slider_positions = [
    [50, 50, 50, 50],
    [10, 100, 30, 65],
    [40, 35, 70, 20],
    [80, 75, 65, 50],
]
for slider_pos in slider_positions:
    # Get description of slider positions
    desc = get_desc(slider_pos)

    # Run and print
    curr_styles = get_styles(X, slider_pos, styles)
    print(f"{desc}: {curr_styles}")
